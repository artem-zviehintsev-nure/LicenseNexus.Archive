﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LicenseNexus.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace LicenseNexus.Domain.Entities;

[Table("Customer")]
[Index(nameof(Email), IsUnique = true)]
[Index(nameof(AccountName), IsUnique = true)]
public class Customer : IEntity
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("partner_id")]
    public int PartnerId { get; set; } // FK

    [Column("account_name")]
    public string AccountName { get; set; } = string.Empty;

    [Column("email")]
    public string Email { get; set; } = string.Empty;

    [Column("legal_name")]
    public string LegalName { get; set; } = string.Empty;

    [Column("city")]
    public string? City { get; set; }

    [Column("region")]
    public string? Region { get; set; }

    [Column("zip_code")]
    public string? ZipCode { get; set; }

    [Column("country_code")]
    [StringLength(3)]
    public string? CountryCode { get; set; }

    [Column("status")]
    public string? Status { get; set; }

    [Column("created_date")]
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    // Navigation Property
    [ForeignKey("PartnerId")]
    public Partner? Partner { get; set; }
}